# output.py
# Contoh output di Python

print("Hello World!")
print("Nama: Zullia Ayzila")
print("NIM: 123456789")
