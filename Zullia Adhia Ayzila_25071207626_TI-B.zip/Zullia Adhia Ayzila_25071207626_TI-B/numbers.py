# Materi: Numbers (int, float, complex)
x = 10    # Integer (bilangan bulat)
y = 2.5   # Float (bilangan desimal)
z = 1j    # Complex (bilangan imajiner)

print(x + y) # Operasi penjumlahan

