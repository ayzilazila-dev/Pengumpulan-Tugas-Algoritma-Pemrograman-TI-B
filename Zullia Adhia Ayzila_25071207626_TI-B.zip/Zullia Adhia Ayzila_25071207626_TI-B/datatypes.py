# Materi: Tipe Data
a = "Hello"    # str
b = 20         # int
c = 3.14       # float
d = ["A", "B"] # list

# Mengecek tipe data menggunakan type()
print(type(a))
print(type(b))

