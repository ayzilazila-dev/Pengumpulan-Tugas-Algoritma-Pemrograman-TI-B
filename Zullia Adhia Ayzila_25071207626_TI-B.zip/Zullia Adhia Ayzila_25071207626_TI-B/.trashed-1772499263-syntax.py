# syntax.py
# Contoh dasar syntax Python

# Statement
print("Ini adalah statement di Python")

# Indentation
if True:
    print("Python menggunakan indentasi")
