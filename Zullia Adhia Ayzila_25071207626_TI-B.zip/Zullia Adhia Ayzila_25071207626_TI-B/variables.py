# Materi: Python Variables
nama = "Zullia Adhia Ayzila"
nim = "25071207626"
umur = 19

print(f"Nama: {nama}")
print(f"NIM: {nim}")

