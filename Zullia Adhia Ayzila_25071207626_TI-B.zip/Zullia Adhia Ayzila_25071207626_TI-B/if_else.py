# Materi: Percabangan If Else
nilai = 85

if nilai >= 80:
    print("Nilai A")
elif nilai >= 70:
    print("Nilai B")
else:
    print("Nilai C")

