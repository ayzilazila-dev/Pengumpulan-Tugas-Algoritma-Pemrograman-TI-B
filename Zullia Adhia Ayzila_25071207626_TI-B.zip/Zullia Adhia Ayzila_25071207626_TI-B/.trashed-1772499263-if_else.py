# if_else.py
# Contoh if else

nilai = 80
if nilai >= 75:
    print("Lulus")
else:
    print("Tidak lulus")
