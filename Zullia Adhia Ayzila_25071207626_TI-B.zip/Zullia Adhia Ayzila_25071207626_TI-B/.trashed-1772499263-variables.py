# variables.py
# Contoh variabel

nama = "Zullia"
umur = 19
print(nama, umur)
