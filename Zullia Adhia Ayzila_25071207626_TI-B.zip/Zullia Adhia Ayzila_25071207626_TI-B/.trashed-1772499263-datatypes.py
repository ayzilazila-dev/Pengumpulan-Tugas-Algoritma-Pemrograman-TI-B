# datatypes.py
# Contoh tipe data

integer = 10
floating = 3.14
string = "Python"
boolean = True

print(type(integer))
print(type(floating))
print(type(string))
print(type(boolean))
