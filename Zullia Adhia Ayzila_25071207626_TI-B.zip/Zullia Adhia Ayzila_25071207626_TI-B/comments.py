# Ini adalah komentar satu baris
print("Komentar tidak akan dieksekusi oleh program")

"""
Ini adalah komentar multi-baris
yang sering digunakan untuk dokumentasi
panjang atau mematikan blok kode sementara.
"""

