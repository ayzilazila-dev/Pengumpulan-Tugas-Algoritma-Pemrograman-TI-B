# Nama: Zullia Adhia Ayzila
# NIM: 25071207626
# Materi: Python Syntax

# Statement dasar
print("Halo, ini adalah pembelajaran syntax Python.")

# Contoh indentasi yang benar
if 5 > 2:
    print("Lima lebih besar dari dua!")

