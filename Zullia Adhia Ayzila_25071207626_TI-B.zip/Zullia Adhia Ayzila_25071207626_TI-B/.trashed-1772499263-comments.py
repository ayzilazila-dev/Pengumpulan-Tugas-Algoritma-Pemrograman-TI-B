# comments.py
# Ini adalah komentar satu baris

'''
Ini adalah
komentar multi baris
'''
print("Contoh komentar di Python")
