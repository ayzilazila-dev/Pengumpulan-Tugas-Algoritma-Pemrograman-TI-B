# Materi: Strings
pesan = "Selamat Belajar Python!"

print(pesan[0])      # Mengambil karakter pertama 
(index 0)
print(pesan.upper()) # Mengubah jadi huruf besar
print(len(pesan))    # Menghitung panjang string

