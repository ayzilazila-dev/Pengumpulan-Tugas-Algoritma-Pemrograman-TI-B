# Materi: Perulangan While
i = 1
while i <= 5:
    print("Perulangan ke-", i)
    i += 1 # Menambah nilai i agar tidak looping 
selamanya

