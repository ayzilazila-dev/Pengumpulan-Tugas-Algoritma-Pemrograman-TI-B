# strings.py
# Contoh string

text = "Belajar Python"
print(text.upper())
print(text.lower())
