# numbers.py
# Contoh number

a = 10
b = 3
print(a + b)
print(a * b)
