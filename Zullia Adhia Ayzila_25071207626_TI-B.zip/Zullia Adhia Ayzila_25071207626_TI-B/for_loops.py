# Materi: Perulangan For
buah = ["Apel", "Jeruk", "Mangga"]

for x in buah:
    print("Saya suka makan", x)

for i in range(3):
    print("Iterasi angka:", i)

