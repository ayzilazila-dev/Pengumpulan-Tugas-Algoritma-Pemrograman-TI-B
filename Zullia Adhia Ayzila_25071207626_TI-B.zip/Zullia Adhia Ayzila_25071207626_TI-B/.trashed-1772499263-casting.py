# casting.py
# Contoh casting

x = 5
y = float(x)
z = str(x)

print(y)
print(z)
