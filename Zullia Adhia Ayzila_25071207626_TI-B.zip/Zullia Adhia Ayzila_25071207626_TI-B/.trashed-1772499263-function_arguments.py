# function_arguments.py
# Contoh fungsi dengan argumen

def tambah(a, b):
    return a + b

hasil = tambah(3, 4)
print(hasil)
