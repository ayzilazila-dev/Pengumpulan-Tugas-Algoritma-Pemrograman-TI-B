# Materi: Operators
x = 15
y = 4

print(x + y)  # Penjumlahan
print(x * y)  # Perkalian
print(x % y)  # Modulus (sisa bagi)
print(x ** 2) # Perpangkatan

