# Materi: Python Function Arguments
def sapa_mahasiswa(nama, nim):
    print(f"Selamat belajar, {nama}! (NIM: {nim})")

sapa_mahasiswa("Zullia Adhia Ayzila", "25071207626")

