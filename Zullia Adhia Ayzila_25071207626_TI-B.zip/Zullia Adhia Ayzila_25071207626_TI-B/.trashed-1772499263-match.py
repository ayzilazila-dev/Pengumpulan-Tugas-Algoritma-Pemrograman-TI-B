# match.py
# Contoh match case (Python 3.10+)

hari = 1
match hari:
    case 1:
        print("Senin")
    case 2:
        print("Selasa")
    case _:
        print("Hari lainnya")
