# for_loops.py
# Contoh for loop

for i in range(1, 6):
    print(i)
