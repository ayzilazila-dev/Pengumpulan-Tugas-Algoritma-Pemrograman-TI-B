# Materi: Casting (Mengubah tipe data)
x = int(2.8)   # x akan menjadi 2
y = float("3") # y akan menjadi 3.0
z = str(100)   # z akan menjadi "100"

print(x, y, z)

