# Materi: Python Output
# Menggunakan fungsi print() untuk menampilkan data 
ke layar
print("Halo, dunia!") 

# Mencetak beberapa argumen sekaligus
print("Nama Saya:", "Zullia")
print("NIM:", 25071207626)

