# Materi: Booleans (True atau False)
print(10 > 9)  # Menghasilkan True
print(10 == 9) # Menghasilkan False

is_active = True
if is_active:
    print("Status aktif!")

