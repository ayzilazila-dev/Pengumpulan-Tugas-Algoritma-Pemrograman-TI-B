# while_loops.py
# Contoh while loop

i = 1
while i <= 5:
    print(i)
    i += 1
