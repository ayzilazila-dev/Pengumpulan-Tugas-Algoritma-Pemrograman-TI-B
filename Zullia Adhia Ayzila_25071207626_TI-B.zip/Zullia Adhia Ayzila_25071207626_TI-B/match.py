# Materi: Match Case (Mirip Switch Case)
hari = "Senin"

match hari:
    case "Senin":
        print("Hari kerja pertama")
    case "Minggu":
        print("Hari libur")
    case _:
        print("Hari lainnya")

